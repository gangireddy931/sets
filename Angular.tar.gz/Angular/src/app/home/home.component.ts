import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor() { }

 ngOnInit(): void {
  }
  registerForm =new FormGroup({
    firstName: new FormControl(''),
    lastName: new FormControl(''),
    age:new FormControl(''),
    address:new FormControl(''),
      street: new FormControl(''),
      city: new FormControl(''),
      state: new FormControl(''),
      pin: new FormControl('')
  
  });
 
  // myFunction1(): void{
  //   debugger;    
  //   }
  onSubmit(){
    console.warn(this.registerForm.value)
  }
}
