import { Component} from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Validators } from '@angular/forms';
import { FormArray } from '@angular/forms';
@Component({
  selector: 'app-hero',
  templateUrl: './hero.component.html',
  styleUrls: ['./hero.component.css']
})
export class HeroComponent  {

  constructor(private fb: FormBuilder) { }

 

  registerForm = this.fb.group({
    firstName: ['', Validators.required],
    lastName: [''],
    age: [''],
    address: this.fb.group({
      address1: [''],
      address2: [''],
      village: [''],
      city: [''],
      state: [''],
      pin: ['']
    }),

    mobiles: this.fb.array([
      this.fb.control('')
    ])
  });

  
  onSubmit() {
    console.warn(this.registerForm.value)
  }
  // get mobiles() {
  //   return this.registerForm.get('mobiles') as FormArray;
  // }
  // AddNewMobile() {
  //   this.mobiles.push(this.fb.control(''));
  // }
  get mobiles() {
    return this.registerForm.get('mobiles') as FormArray;
  }
  addMobiles() {
    this.mobiles.push(this.fb.control(''));
  }
}
